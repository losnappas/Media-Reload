## MEDIA RELOAD

Hold control, or another key of choice, and seek video/audio to reset its buffer.

Mac users should probably rebind the key in the preferences.
